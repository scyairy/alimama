
#include "stm32f10x.h"
#include <stdio.h>

extern double angle_x;