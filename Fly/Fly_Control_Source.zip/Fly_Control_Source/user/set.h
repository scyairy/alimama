#ifndef __SET_H
#define __SET_H

extern char Debug;
extern char Send_Angle;

#define CAP_TIM		TIM3    //超声波使用的定时器
#endif