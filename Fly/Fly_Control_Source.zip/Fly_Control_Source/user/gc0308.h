#ifndef __GC0308_H
#define __GC0308_H

#include "i2c.h"

#define GC0308_Address 0x42

void gc0308_test();
void TIM1_Init();
void gc0308_work();


#endif