#ifndef __TIMER_H
#define __TIMER_H
#include "stm32f10x.h"

void Tim2_Init();
void TIMER_Init(TIM_TypeDef *TIMER);
void TIM3_Cap_Init();
#endif