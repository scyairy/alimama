#ifndef __LINUX_INIT_H__
#define __LINUX_INIT_H__
#endif
