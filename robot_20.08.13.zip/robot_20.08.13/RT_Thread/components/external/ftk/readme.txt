
1). remove hidden directory "./ftk/.svn"

2). svn checkout http://ftk.googlecode.com/svn/trunk/ ftk

3). create a directory name "ftk" in your sd card

4). copy directory "./ftk/data", "./ftk/theme", "./ftk/testdata" to directory "ftk" which in your sd card

5). make sure RT_USING_FTK is defined and RT_USING_RTGUI is undefined

6). compile it

                                                   Jiao JinXing <jiaojinxing1987@gmail.com>
